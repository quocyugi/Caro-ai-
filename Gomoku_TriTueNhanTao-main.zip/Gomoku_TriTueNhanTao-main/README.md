# Go-Moku AI using the Minimax Algorithm with Alpha-Beta Pruning

Gameplay:

https://raw.githubusercontent.com/NguyenQuocKhanh0/Gomoku_TriTueNhanTao/main/images/gameplay-sample.png
